<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productcommentsdisqus}prestashop>configuration_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{productcommentsdisqus}prestashop>configuration_d4bb98435dac2a8c84038dd4cab46454'] = 'Tu nombre corto Disqus';
$_MODULE['<{productcommentsdisqus}prestashop>configuration_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{productcommentsdisqus}prestashop>productcommentsdisqus_97fbefa14a5f6b5437596234b95c7f91'] = 'Comentario de Disqus';
$_MODULE['<{productcommentsdisqus}prestashop>productcommentsdisqus_b00d1b903965c01a895ae827d09d1069'] = 'Publicar un comentario para este producto desde Disqus.';
$_MODULE['<{productcommentsdisqus}prestashop>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Comentarios';
